class Record {
    constructor(subjectCode, desc, credits, room) {
      this.subjectCode = subjectCode;
      this.desc = desc;
      this.credits = credits;
      this.room = room;
    }
  }
  
  class UI {
    static displayRecord() {
      const records = Store.getRecord();
      records.forEach((record) => UI.addRecordToList(record));
    }
  
    static addRecordToList(record) {
      const list = document.querySelector('#record-list');
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${record.subjectCode}</td>
        <td>${record.desc}</td>
        <td>${record.credits}</td>
        <td>${record.room}</td>
        <td><a href="#" class="btn btn-danger btn-sm delete">X</a></td>
      `;
      list.appendChild(row);
    }
  
    static deleteRecord(target) {
      if (target.classList.contains('delete')) {
        target.parentElement.parentElement.remove();
      }
    }
  
    static showAlert(message, className) {
      const div = document.createElement('div');
      div.className = `alert alert-${className}`;
      div.appendChild(document.createTextNode(message));
      const container = document.querySelector('.container');
      const form = document.querySelector('#records-form');
      container.insertBefore(div, form);
      setTimeout(() => document.querySelector('.alert').remove(), 3000);
    }
  
    static clearFields() {
     document.querySelector('#subjectCode').value = '';
      document.querySelector('#desc').value = '';
      document.querySelector('#credits').value = '';
      document.querySelector('#room').value = '';
    }
  }
  
  class Store {
    static getRecord() {
      let records;
      if (localStorage.getItem('records') === null) {
        records = [];
      } else {
        records = JSON.parse(localStorage.getItem('records'));
      }
      return records;
    }
  
    static addRecord(record) {
      const records = Store.getRecord();
      records.push(record);
      localStorage.setItem('records', JSON.stringify(records));
    }
  
    static removeRecord(room) {
      const records = Store.getRecord();
      records.forEach((record, index) => {
        if (record.room === room) {
          records.splice(index, 1);
        }
      });
      localStorage.setItem('records', JSON.stringify(records));
    }
  }
  
  document.addEventListener('DOMContentLoaded', UI.displayRecord);
  
  document.querySelector('#records-form').addEventListener('submit', (e) => {
    e.preventDefault();
  
    const subjectCode = document.querySelector('#subjectCode').value;
    const desc = document.querySelector('#desc').value;
    const credits = document.querySelector('#credits').value;
    const room = document.querySelector('#room').value;
  
    if (subjectCode === '' || desc === '' || credits === '' || room === '') {
      UI.showAlert('Please fill in all fields', 'danger');
    } else {
      const record = new Record(subjectCode , desc, credits, room);
  
      UI.addRecordToList(record);
  
      Store.addRecord(record);
  
      UI.showAlert('Record Added', 'success');
  
      UI.clearFields();
    }
  });
  
  document.querySelector('#record-list').addEventListener('click', (e) => {
    UI.deleteRecord(e.target);
  
    Store.removeRecord(e.target.parentElement.previousElementSibling.textContent);
  
    UI.showAlert('Record Removed', 'success');
  });