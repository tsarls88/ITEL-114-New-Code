let userinfo = {
    fname:"Earl",
    lname:"Arboleda",
    mname:"Camp",
    userName:"Earl09",
    pass:"123",
    email:"awdawd@awd.co.",
    course:"cawd",
    schoolID: null,
}

function login(){
    var usern = document.getElementById("Username").value;
    var pass = document.getElementById("password").value;
   document.getElementById("sample").innerHTML = usern + " " + pass; 
    if(usern == "" || pass ==""){
        document.getElementById("sample").innerHTML = "Please enter";
    }else if(usern == userinfo.userName && pass == userinfo.pass){
        document.location = 'home.html';
    }else{
        document.getElementById("sample").innerHTML = "Invalid Username or Password";
    }
}