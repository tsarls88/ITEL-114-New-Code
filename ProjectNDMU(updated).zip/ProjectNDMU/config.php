<?php
$conn = new mysqli('localhost', 'root', '', 'user_db');

if (!$conn) {
   die(mysqli_error($con));
}
?>