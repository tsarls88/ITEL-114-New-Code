<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        crossorigin="anonymous">
    <title>Display Study Load</title>
</head>

<body>
    <div class="container">
        <button class="btn btn-primary my-5"><a href="CRUDrecords.php" class="text-light">Add Study Load</a>
        </button>
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Subject Code</th>
                    <th scope="col">Description</th>
                    <th scope="col">Credits</th>
                    <th scope="col">Room</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM `study_load`";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $SubjectCode = $row['SubjectCode'];
                        $Description = $row['Description'];
                        $Credits = $row['Credits'];
                        $Room = $row['Room'];
                        echo '<tr>
                  <th scope="row"> ' . $SubjectCode . '</th>
                  <td>' . $Description . '</td>
                  <td>' . $Credits . '</td>
                  <td>' . $Room . '</td>
                  <td>
                  <button class = "btn btn-primary"><a href="update.php" class = "text-light"> Update</a></button>
                  <button class = "btn btn-danger"><a href="delete.php? deleteid = '.$SubjectCode.'"class = "text-light"> Delete</a></button>
                  </td>
              </tr>';
                    }
                }
                ?>

            </tbody>
        </table>

    </div>
</body>

</html>