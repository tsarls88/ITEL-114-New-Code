<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Records</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container1 my-5">
        <h1>Records Section</h1>
        <form method="post">
            <div class="form-group">
                <label for="subjectCode">Subject Code</label>
                <input type="text" name="SubjectCode" id="subjectCode" class="form-control" placeholder="Enter Subject Code">
            </div>
            <div class="form-group">
                <label for="desc">Description</label>
                <input type="text" name="Description" id="desc" class="form-control" placeholder="Enter Description">
            </div>
            <div class="form-group">
                <label for="credits">Credits</label>
                <input type="text" name="Credits" id="credits" class="form-control" placeholder="Enter Credits">
            </div>
            <div class="form-group">
                <label for="room">Room</label>
                <input type="text" name="Room" id="room" class="form-control" placeholder="Enter Room">
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Add Study Load</button>
        </form>
        <table class="table">
            <thead>
                <tr>
                    <th>Subject Code</th>
                    <th>Description</th>
                    <th>Credits</th>
                    <th>Room</th>
                    <th></th>
                </tr>
            </thead>
            <tbody id="record-list">

            </tbody>
        </table>
    </div>
    <script src="assets/js/records.js"></script>
</body>

</html>