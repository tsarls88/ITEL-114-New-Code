<?php

include 'connect.php';
if(isset($_GET['deleteid'])){
    $SubjectCode = $_GET['deleteid'];

    $sql = "delete from `study_load` where SubjectCode = $SubjectCode";
    $result = mysqli_query($con,$sql);
    if($result){
        echo "Deleted Successfully";
    }else{
        die(mysqli_error($con));
    }
}
?>