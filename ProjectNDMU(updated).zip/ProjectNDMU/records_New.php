<?php
include 'connect.php';
if (isset($_POST['submit'])) {
    $SubjectCode = $_POST['SubjectCode'];
    $Description = $_POST['Description'];
    $Credits = $_POST['Credits'];
    $Room = $_POST['Room'];

    $sql = "insert into `study_load` (SubjectCode,Description,Credits,Room) values('$SubjectCode','$Description','$Credits','$Room')";
    $result = mysqli_query($con, $sql);
    if ($result) {
        // echo "Data Successfully Connected";
        header('location:CRUDrecords.php');
    } else {
        die(mysqli_error($con));
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link href='assets/css/records.css' rel='stylesheet' />
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME CSS -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet" />
     <!-- FLEXSLIDER CSS -->
<link href="assets/css/flexslider.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />    
  <!-- Google	Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css' />
    <link href='assets/css/popup101.css' rel='stylesheet'/>
    <title>Records</title>
</head>

<body>
     <!--NAVBAR SECTION START-->
     <div class="navbar navbar-inverse navbar-fixed-top " id="menu">
        <div class="container">
            <div class="navbar-header">
                <img class="logo-custom" src="assets/img/ndmu.png" alt="" />
                <ul class="nav navbar-nav navbar-right">
                    <li><a class="ndmusign">NDMU</a></li>
            </div>
            <div class="navbar-collapse collapse move-me">
                <ul class="nav navbar-nav navbar-right">
                    <li><button class="home" id="home" onclick="homE()">HOME</button></il>
                    <li><button class="offices" id="office">OFFICES</button></li>
                    <li><button class="profile" id="profile">PROFILE</button></li>
                    <li><button class="settings" id="about">ABOUT</button></li>
                    <li><button class="support" id="logout" onclick ="logout()">LOGOUT</button></li>
                </ul>
            </div>

        </div>
    </div>
    <!-- Popup -->
    <div id="popup" class="PopupDesign">
        <div class="PopupContent">
            <span class="close">&times;</span>
            <div class="flexcon">
                <div class="left">
                    <button id="rs" class="popbutt" onclick="CRUDrec()">Records Section</button>
                    <button id="bo" class="popbutt" onclick="bussinesOf()">Business Office</button>
                    <button id="cd" class="popbutt">College Department</button>
                </div>
                <div class="right">
                    <button id="lib" class="popbutt" onclick="library()">Library</button>
                    <button id="clnc" class="popbutt" onclick="clinic()">Clinic</button>
                    <button id="guid" class="popbutt" onclick="guidance()">Guidance</button>

                </div>
            </div>
        </div>
    </div>
    <!-- End of Popup -->
    <div class="container1 my-3">
        <h1>Records Section</h1>
        <form method="post">
            <div class="form-group">
                <label for="subjectCode">Subject Code</label>
                <input type="text" name="SubjectCode" id="subjectCode" class="form-control my-3"
                    placeholder="Enter Subject Code" autocomplete="off">
            </div>
            <div class="form-group">
                <label for="desc">Description</label>
                <input type="text" name="Description" id="desc" class="form-control my-3"
                    placeholder="Enter Description" autocomplete="off">
            </div>
            <div class="form-group">
                <label for="credits">Credits</label>
                <input type="text" name="Credits" id="credits" class="form-control my-3" placeholder="Enter Credits"
                    autocomplete="off">
            </div>
            <div class="form-group">
                <label for="room">Room</label>
                <input type="text" name="Room" id="room" class="form-control my-3" placeholder="Enter Room"
                    autocomplete="off">
            </div>
            <button type="submit" name="submit" class="btn btn-primary my-3">Add Study Load</button>
            <button onclick="window.print()" class = "btn btn-primary">Print Study Load</button>
        </form>
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Subject Code</th>
                    <th scope="col">Description</th>
                    <th scope="col">Credits</th>
                    <th scope="col">Room</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM `study_load`";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $SubjectCode = $row['SubjectCode'];
                        $Description = $row['Description'];
                        $Credits = $row['Credits'];
                        $Room = $row['Room'];
                        echo '<tr>
                  <th scope="row"> ' . $SubjectCode . '</th>
                  <td>' . $Description . '</td>
                  <td>' . $Credits . '</td>
                  <td>' . $Room . '</td>
                  <td>
                  <button class = "btn btn-primary" class = "text-light"><a href="update.php" > Update</a></button>
                  <button class = "btn btn-danger"><a href="delete.php? deleteid = ' . $SubjectCode . '"class = "text-light"> Delete</a></button>
                  </td>
              </tr>';
                    }
                }
                ?>

            </tbody>
        </table>
    </div>
    <script src="assets/js/popup.js"></script>
    <script src="assets/js/custom.js"></script>
</body>

</html>