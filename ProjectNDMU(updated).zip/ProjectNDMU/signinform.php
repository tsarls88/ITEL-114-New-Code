<?php
session_start();

include 'config.php';

if (isset($_POST['submit'])) {

    $studentNo = mysqli_real_escape_string($conn, $_POST['studentNo']);
    $pass = md5($_POST['password']);

    $select = "SELECT * FROM `sign_form` WHERE studentNo = '$studentNo' AND password = '$pass' ";

    $result = mysqli_query($conn, $select);

    if (mysqli_num_rows($result) > 0) {

        $row = mysqli_fetch_array($result);

        if ($row['studentNo'] == $studentNo) {

            $_SESSION['studentNo'] = $row['studentNo'];
            header('Location: home(updated).html');
            exit();

        } else {
            $error = 'Incorrect student ID number or password';
        }
    } else {
        $error = 'Incorrect student ID number or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>

    <!-- custom css file link  -->
    <link href='assets/css/signin.css' rel='stylesheet' />

</head>

<body>

    <div class="form-container">

        <form action="" method="post">
            <h3>Login Now</h3>
            <?php
            if (isset($error)) {
                echo '<span class="error-msg">' . $error . '</span>';
            }
            ?>
            <input type="text" name="studentNo" placeholder="Enter Student ID Number" required>
            <input type="password" name="password" autocomplete="current-password" id="id_password"
                placeholder="Enter your password" required>
            <input type="submit" name="submit" value="Login Now" class="form-btn">
            <p>Don't have an account? <a href="signupform.php">Register Now</a></p>
        </form>

    </div>
</body>

</html>