<!-- Database Connection -->
<?php
include 'config.php';

if (isset($_POST['submit'])) {

  $fName = mysqli_real_escape_string($conn, $_POST['fName']);
  $mName = mysqli_real_escape_string($conn, $_POST['mName']);
  $lName = mysqli_real_escape_string($conn, $_POST['lName']);
  $studentNo = mysqli_real_escape_string($conn, $_POST['studentNo']);
  $birthday = mysqli_real_escape_string($conn, $_POST['birthday']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $phoneNum = mysqli_real_escape_string($conn, $_POST['phoneNum']);
  $pass = md5($_POST['password']);
  $cpass = md5($_POST['Conpassword']);

  $select = "SELECT * FROM `sign_form` WHERE studentNo = '$studentNo' && password = '$pass' ";

  $result = mysqli_query($conn, $select);
  if (mysqli_num_rows($result) > 0) {
    $error[] = 'User Already Exist!';

  } else {
    if ($pass != $cpass) {
      $error[] = 'Password not matched!';
    } else {
      $insert = "INSERT INTO sign_form(studentNo,fName,lName,mName,birthday,email,phoneNum,password) VALUES ('$studentNo','$fName',' $mName','$lName','$birthday','$email','$phoneNum','$pass')";
      mysqli_query($conn, $insert);
      header('location:signinform.php');
    }
  }

}
;
?>
<!-- Database Connection -->

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://kit.fontawesome.com/d49126cf78.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
  <link rel="stylesheet" href="assets/css/signup.css">
  <title>Registration Form</title>
</head>

<body>
  <div class="container">
    <div class="title">Registration</div>
    <div class="content">
      <form id="form" action="#" method="post">
        <?php
        if (isset($error)) {
          foreach ($error as $error) {
            echo '<span class = "error-msg">' . $error . '</span>';
          }
        }
        ?>
        <div class="user-details">
          <div class="input-box">
            <span class="details">Student ID No.</span>
            <input type="text" name="studentNo" placeholder="Enter Student ID Number" required>
          </div>
          <div class="input-box">
            <span class="details">First Name</span>
            <input type="text" name="fName" placeholder="Enter your First name" required>
          </div>
          <div class="input-box">
            <span class="details">Last Name</span>
            <input type="text" name="lName" placeholder="Enter your Last name" required>
          </div>
          <div class="input-box">
            <span class="details">Middle Name</span>
            <input type="text" name="mName" placeholder="Enter your Middle name">
          </div>
          <div class="input-box">
            <label for="birthday">Birthday</label>
            <input type="date" name="birthday" name="birthday">
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" name="email" placeholder="Enter your email">
          </div>
          <div class="input-box">
            <span class="details">Phone Number</span>
            <input type="text" name="phoneNum" placeholder="Enter your number" required>
          </div>
          <div class="input-box">
            <span class="details">Password</span>
            <input type="password" name="password" autocomplete="current-password" id="id_password"
              placeholder="Enter your password" required>
            <i class="far fa-eye" id="togglePassword" style="margin-left:-30px; cursor: pointer;"></i>
          </div>
          <div class="input-box">
            <span class="details">Confirm Password</span>
            <input type="password" name="Conpassword" autocomplete="current-password" id="id_confirm"
              placeholder="Confirm your password" required>
            <i class="far fa-eye" id="toggleConfirm" style="margin-left:-30px; cursor: pointer;"></i>
          </div>
        </div>
        <div class="button">
          <input type="submit" name="submit" value="Register">
          <p>Already have an account? <a href="signinform.php">Login Now</a></p>
        </div>
      </form>
    </div>
  </div>
  <script src="assets/js/signup.js"></script>
</body>

</html>