<?php
>
phpinfo();
