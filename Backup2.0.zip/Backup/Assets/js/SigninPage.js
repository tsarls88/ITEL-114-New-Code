import { json } from "body-parser";

const form = document.querySelector('#form');
form.addEventListener('submit', (e) => {
   e.preventDefault();
    const fd = new FormData(form);
    const user = Object.fromEntries(fd);


    console.log(user);

    const json1 = JSON.stringify(user);


    window.location.href = "LoginPage.html";

});

export default json1;
