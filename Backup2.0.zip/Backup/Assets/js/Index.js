// Get the modal
var modal = document.getElementById("popup");

// Get the button that opens the modal
var btn = document.getElementById("office");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

const btnBusiness = document.querySelector("#bo");
btnBusiness.addEventListener('click', (e) =>{
  window.location.href = "Business.html"
});

const btnhome = document.querySelector("#home");
btnhome.addEventListener('click', (e) =>{
  window.location.href = "Home.html"
});

const btnprofile = document.querySelector("#profile")
btnprofile.addEventListener('click', (e) =>{
  window.location.href = "Profile.html"
});

const btnLogout = document.querySelector("#logout")
btnLogout.addEventListener('click', (e) =>{
  window.location.href = "LoginPage.html"
});

const btnrs = document.querySelector("#rs")
btnrs.addEventListener('click', (e) =>{
  window.location.href = "Records.html"
});

const btnclnc = document.querySelector("#clnc")
btnclnc.addEventListener('click', (e) =>{
  window.location.href = "Clinic.html"
});

const btncol = document.querySelector("#cd")
btncol.addEventListener('click', (e) =>{
  window.location.href = "College.html"
});

const btngd = document.querySelector("#guid")
btngd.addEventListener('click', (e) =>{
  window.location.href = "Guidance.html"
});

const btnlib = document.querySelector("#lib")
btnlib.addEventListener('click', (e) =>{
  window.location.href = "Library.html"
});

const redir = document.querySelector("#redir")
redir.addEventListener('click', (e) =>{
  window.location.href = "http://web-opac.ndmu.edu.ph/"
});